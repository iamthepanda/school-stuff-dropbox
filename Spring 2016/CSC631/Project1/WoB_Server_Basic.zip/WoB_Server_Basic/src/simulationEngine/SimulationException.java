package simulationEngine;

/**
 *
 * @author Gary
 */
public class SimulationException extends Exception {
    
    public SimulationException(String string) {
        super(string);
    }
}
