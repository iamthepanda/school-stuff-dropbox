/**
 * 
 */
package simulationEngine.config;

/**
 * @author Sonal
 *
 */
public enum ManipulatingNodePropertyName
{
	Connectance, 
	Probability, 
	SpeciesCount, 
	PredatorLink,
	PreyLink;
}
