package PJ1;

public class SimpleFraction implements SimpleFractionInterface, Comparable<SimpleFraction>
{
	private	int num;	
	private	int den;	

	public SimpleFraction(){num = 0; den =1; }	

	public SimpleFraction(int num, int den)
	{
		 this.num =num ; this.den = den;
               
                if(this.den < 0)
                {
                    this.num = -num; this.den = -den;
                }
                if(this.den ==0)
                {
                    throw new SimpleFractionException();
                }
	}	

	public void setSimpleFraction(int num, int den)
	{
            this.num = num; this.den = den;
		
                if(den == 0)
                    throw new SimpleFractionException();
                
	}	

	public double toDouble()
	{
                return this.num/(double)this.den;	
	}	

	public SimpleFractionInterface add(SimpleFractionInterface secondFraction)
	{
            SimpleFraction secFrac = (SimpleFraction)secondFraction;
            
            int newNum1 = (secFrac.den * this.num);
            int newNum2 = (secFrac.num * this.den);
            int newDen = (this.den * secFrac.den);
            int newNum =(newNum1 + newNum2);
           SimpleFraction result = new SimpleFraction(newNum,newDen);
            if(newDen == 0)
            {
                throw new SimpleFractionException();
            }
           result.reduceSimpleFractionToLowestTerms();
            return result; 
	}	

	public SimpleFractionInterface subtract(SimpleFractionInterface secondFraction)
	{
          SimpleFraction secFrac = (SimpleFraction)secondFraction;
            
            int newNum1 = (secFrac.den * this.num);
            int newNum2 = (secFrac.num * this.den);
            int newDen = (this.den * secFrac.den);
            int newNum =(newNum1 - newNum2);
           SimpleFraction result = new SimpleFraction(newNum,newDen);
            if(newDen ==0)
            {
                throw new SimpleFractionException();
            }
            result.reduceSimpleFractionToLowestTerms();
            return result; 
	}	

	public SimpleFractionInterface multiply(SimpleFractionInterface secondFraction)
	{
            SimpleFraction secFrac = (SimpleFraction)secondFraction;
         
            int newNum = (secFrac.num * this.num);
            int newDen = (this.den * secFrac.den);
            if(newDen == 0)
             {
                 throw new SimpleFractionException();
             }
           SimpleFraction result = new SimpleFraction(newNum,newDen);
            
            result.reduceSimpleFractionToLowestTerms();
            
            return result;             
	}

	public SimpleFractionInterface divide(SimpleFractionInterface secondFraction)
	{
               SimpleFraction secFrac = (SimpleFraction)secondFraction;
         
            int newNum = (secFrac.den * this.num);
            int newDen = (this.den * secFrac.num);
           if(newDen == 0)
           {
               throw new SimpleFractionException();
           }
            SimpleFraction result = new SimpleFraction(newNum,newDen);
             
           result.reduceSimpleFractionToLowestTerms();
             
            return result;       
	}

	public SimpleFractionInterface getReciprocal() 
	{
               SimpleFraction Reciprocal = new SimpleFraction(this.den,this.num);
                if(Reciprocal.equals(0))
                {
                    throw new SimpleFractionException();
                }
                else
                    return Reciprocal;
	} 


	public boolean equals(Object other)
	{
            if(other == this)
               return true;
            else
               return false;
	} 


	public int compareTo(SimpleFraction other)
	{
            double compFrac1 = this.toDouble();
            double compFrac2 = other.toDouble();
           if(compFrac1 == compFrac2)
               return 0;
           if(compFrac1 < compFrac2)
               return -1;
           else
               return 1; 
	} 

	
	public String toString()
	{
		return this.num + "/" + this.den;
	}

        //-----------------------------------------------------------------
        //  private methods start here
        //-----------------------------------------------------------------

	private void reduceSimpleFractionToLowestTerms()
	{
            int gcd = this.GCD(den , num);
            if(gcd < 0)
            {
                gcd = -gcd;
            }
            num /= gcd;
            den /= gcd; 
	}	

	private int GCD(int integerOne, int integerTwo)
	{
		 int result;

		 if (integerOne % integerTwo == 0)
			result = integerTwo;
		 else
			result = GCD(integerTwo, integerOne % integerTwo);

		 return result;
	}


	//-----------------------------------------------------------------
	//  Simple test is provided here 

	public static void main(String[] args)
	{
		SimpleFractionInterface firstOperand = null;
		SimpleFractionInterface secondOperand = null;
		SimpleFractionInterface result = null;
                double doubleResult = 0.0;

		SimpleFraction nineSixteenths = new SimpleFraction(9, 16);  // 9/16
		SimpleFraction oneFourth = new SimpleFraction(1, 4);        // 1/4

		System.out.println("\n=========================================\n");
		// 7/8 + 9/16
		firstOperand = new SimpleFraction(7, 8);
		result = firstOperand.add(nineSixteenths);
		System.out.println("The sum of " + firstOperand + " and " +
				nineSixteenths + " is \t\t" + result);
		System.out.println("\tExpected result :\t\t23/16\n");

		// 9/16 - 7/8
		firstOperand = nineSixteenths;
		secondOperand = new SimpleFraction(7, 8);
		result = firstOperand.subtract(secondOperand);
		System.out.println("The difference of " + firstOperand	+
				" and " +	secondOperand + " is \t" + result);
		System.out.println("\tExpected result :\t\t-5/16\n");


		// 15/-2 * 1/4
		firstOperand = new SimpleFraction(15, -2); 
		result = firstOperand.multiply(oneFourth);
		System.out.println("The product of " + firstOperand	+
				" and " +	oneFourth + " is \t" + result);
		System.out.println("\tExpected result :\t\t-15/8\n");

		// (-21/2) / (3/7)
		firstOperand = new SimpleFraction(-21, 2); 
		secondOperand= new SimpleFraction(3, 7); 
		result = firstOperand.divide(secondOperand);
		System.out.println("The quotient of " + firstOperand	+
				" and " +	secondOperand + " is \t" + result);
		System.out.println("\tExpected result :\t\t-49/2\n");

		// -21/2 + 7/8
		firstOperand = new SimpleFraction(-21, 2); 
		secondOperand= new SimpleFraction(7, 8); 
		result = firstOperand.add(secondOperand);
		System.out.println("The sum of " + firstOperand	+
				" and " +	secondOperand + " is \t\t" + result);
		System.out.println("\tExpected result :\t\t-77/8\n");


                // 0/10, 5/(-15), (-22)/7
		firstOperand = new SimpleFraction(0, 10); 
                doubleResult = firstOperand.toDouble();
		System.out.println("The double floating point value of " + firstOperand	+ " is \t" + doubleResult);
		//System.out.println("\tExpected result \t\t\t0.0\n");
		firstOperand = new SimpleFraction(1, -3); 
                doubleResult = firstOperand.toDouble();
		System.out.println("The double floating point value of " + firstOperand	+ " is \t" + doubleResult);
		System.out.println("\tExpected result \t\t\t-0.333333333...\n");
		firstOperand = new SimpleFraction(-22, 7); 
                doubleResult = firstOperand.toDouble();
		System.out.println("The double floating point value of " + firstOperand	+ " is \t" + doubleResult);
		System.out.println("\tExpected result \t\t\t-3.142857142857143");
		System.out.println("\n=========================================\n");
		firstOperand = new SimpleFraction(-21, 2); 
		System.out.println("First = " + firstOperand);
		// equality check
		System.out.println("check First equals First: ");
		if (firstOperand.equals(firstOperand))
			System.out.println("Identity of fractions OK");
		else
			System.out.println("ERROR in identity of fractions");

		secondOperand = new SimpleFraction(-42, 4); 
		System.out.println("\nSecond = " + secondOperand);
		System.out.println("check First equals Second: ");
		if (firstOperand.equals(secondOperand))
			System.out.println("Equality of fractions OK");
		else
			System.out.println("ERROR in equality of fractions");

		// comparison check
		SimpleFraction first  = (SimpleFraction)firstOperand;//-21/2
		SimpleFraction second = (SimpleFraction)secondOperand;// -42/4
		
		System.out.println("\ncheck First compareTo Second: ");
		if (first.compareTo(second) == 0)
			System.out.println("SimpleFractions == operator OK");
		else
			System.out.println("ERROR in fractions == operator");

		second = new SimpleFraction(7, 8);
		System.out.println("\nSecond = " + second);
		System.out.println("check First compareTo Second: ");
		if (first.compareTo(second) < 0)
			System.out.println("SimpleFractions < operator OK");
		else
			System.out.println("ERROR in fractions < operator");

		System.out.println("\ncheck Second compareTo First: ");
		if (second.compareTo(first) > 0)
			System.out.println("SimpleFractions > operator OK");
		else
			System.out.println("ERROR in fractions > operator");

		System.out.println("\n=========================================");

		System.out.println("\ncheck SimpleFractionException: 1/0");
		try {
			SimpleFraction a1 = new SimpleFraction(1, 0);		    
		        System.out.println("Error! No SimpleFractionException");
		}
		catch ( SimpleFractionException fe )
           	{
              		System.err.printf( "Exception: %s\n", fe );
           	} 
		System.out.println("Expected result : SimpleFractionException!\n");

		System.out.println("\ncheck SimpleFractionException: division");
		try {
			SimpleFraction a2 = new SimpleFraction();		    
			SimpleFraction a3 = new SimpleFraction(1, 2);		    
			a3.divide(a2);
		        System.out.println("Error! No SimpleFractionException");
		}
		catch ( SimpleFractionException fe )
           	{
              		System.err.printf( "Exception: %s\n", fe );
           	} 
		System.out.println("Expected result : SimpleFractionException!\n");
	}
}

