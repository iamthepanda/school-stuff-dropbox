package pj1;

public class SimpleFraction implements SimpleFractionInterface, Comparable<SimpleFraction> {

    private int num; /*numerator of type int*/

    private int den; /*denominator of type int*/


    public SimpleFraction() {
        setSimpleFraction(0, 1);/*default fration is 0/1*/

    }	// end default constructor

    public SimpleFraction(int num, int den) {

        int numerator = num;
        int denominator = den;

        setSimpleFraction(num, den);
    }	// end constructor

    public void setSimpleFraction(int num, int den) { /*Sets a fraction to a given value.*/
        /*num is the integer numerator and den is the integer denominator */

        if (den == 0) {
            throw new ArithmeticException("Denominator is 0");        /*in SimpleFrcationInterface is says to throw ArithmeticException if denominator is 0 
                                                                      but in SimpleFraction it says must throw SimpleFractionException in case of errors so
                                                                      I did what it said in SimpleFractionInterface  */
        }
        this.num = num;
        this.den = den;
    }
    	// end setFraction

    private int getDen() {
        return this.den;
    }

    private int getNum() {
        return this.num;
    }

    public double toDouble() { /*convert a fraction to double value*/

        double numerator = 0;
        double num;
        num = numerator;
        double denominator = 0;
        double den;
        den = denominator;

        return num / den; /*returns  the double floating point value of a fraction */

    }

    public SimpleFractionInterface add(SimpleFractionInterface secondFraction) {
        /*formula for adding 2 fractions is a/b + c/d is (ad + cb)/(bd)*/
        int a; /*numerator of first fraction*/

        int b; /*denominator of first fraction*/

        int c; /*numerator of second fraction*/

        int d; /*denominator of second fraction*/

        a = this.num;
        b = this.den;
        c = secondFraction.getnum();
        d = secondFraction.getden();
        int firstOperand = ((this.num * secondFraction.getden()) + (secondFraction.getnum() * this.den));
        int secondOperand = (this.den * secondFraction.getden());
        SimpleFraction result = new SimpleFraction(firstOperand, secondOperand) {
        };

        return result;        // return result which is a new SimpleFraction object

    }	// end add

    public SimpleFractionInterface subtract(SimpleFractionInterface secondFraction) { /*Subtracts two fractions*/
        /*formula to subtract two fractions is a/b - c/d is (ad - cb)/(bd)*/

        int a; /*numerator of first fraction*/

        int b; /*denominator of first fraction*/

        int c; /*numerator of second fraction*/

        int d; /*denominator of second fraction*/

        a = this.num;
        b = this.den;
        c = secondFraction.getnum();
        d = secondFraction.getden();

        int firstOperand = ((this.num * this.num * secondFraction.getden()) - (secondFraction.getnum() * this.den));
        int secondOperand = (this.den * secondFraction.getden());
        SimpleFraction result = new SimpleFraction(firstOperand, secondOperand) {

        };

        return result;        // return result which is a new SimpleFraction object

    }	// end subtract

    public SimpleFractionInterface multiply(SimpleFractionInterface secondFraction) { /* Multiplies two fractions */
        /*formula to multiply two fractions  a/b * c/d is (ac)/(bd)*/

        int a; /*numerator of first fraction*/

        int b; /*denominator of first fraction*/

        int c; /*numerator of second fraction*/

        int d; /*denominator of second fraction*/

        a = this.num;
        b = this.den;
        c = secondFraction.getnum(); /*secondFraction is a fraction that is the second operand of the multiplication*/

        d = secondFraction.getden();

        int firstOperand = (this.num * secondFraction.getnum());
        int secondOperand = (this.den * secondFraction.getden());

        SimpleFraction result = new SimpleFraction(firstOperand, secondOperand) {

        };
        return result;        /*returns a fraction which is the product of the invoking fraction and the secondFraction*/

    }	// end multiply

    public SimpleFractionInterface divide(SimpleFractionInterface secondFraction) { /* Divides two fractions*/

        if (secondFraction.getnum() == 0) {
            throw new SimpleFractionException("SecondFraction is 0"); /*throws SimpleFractionException if secondFraction is 0 */

        }
        {
            /*formula to divide two fractions is  a/b / c/d is (ad)/(bc)*/
            int a; /*numerator of first fraction*/

            int b; /*denominator of first fraction*/

            int c; /*numerator of second fraction*/

            int d; /*denominator of second fraction*/

            a = this.num;
            b = this.den;
            c = secondFraction.getnum(); /*secondFraction a fraction that is the second operand of the division*/

            d = secondFraction.getden();
            int firstOperand = (this.num * secondFraction.getden());
            int secondOperand = (this.den * secondFraction.getnum());

            SimpleFraction result = new SimpleFraction(firstOperand, secondOperand) {

            };

            return result;        /*returns a fraction which the quotient of the invoking fraction and the secondFraction*/

        } // end divide
    }

    public SimpleFractionInterface getReciprocal() { /*Get's the fraction's reciprocal  */

        if (this.num == 0) {
            throw new SimpleFractionException("The new number has a denominaotr of 0");       /*throws SimpleFractionException if the new number with denominator is 0*/

        }
        {
            int a; /*numerator of fraction*/

            int b; /*denominator of fraction*/

            a = this.num;
            b = this.den;
            int firstOperand = this.num;
            int secondOperand = this.den;

            SimpleFraction result = new SimpleFraction(secondOperand, firstOperand) {

            };

            return result; /*returns the reciprocal of the invoking fraction */

        }
    }// end getReciprocal

    public boolean equals(Object other) {

        SimpleFractionInterface fraction = (SimpleFraction) other; /*downcast reference parameter*/
        if (this == other) { /*Use "this" to access this object */

            return true;
        }
        if (other instanceof SimpleFractionInterface) {
            return (num == SimpleFractionInterface.num);
        }
        return false;
    }

    public int compareTo(SimpleFraction other) {
        int result;
        if (this.equals(other)) {
            result = 0;
        } else if (this.num * other.getden() < other.getnum() * this.den) {
            result = -1;
        } else {
            result = 1;
        }
        return result;
    } // end compareTo

    public String toString() {
        return num + "/" + den;
    } // end toString

    private void reduceSimpleFractionToLowestTerms() { /*Reduces a fraction to lowest terms. */

        {
            int GCD;

            if (this.num > 0) {
                GCD = reduceSimpleFractionToLowestTerms(this.num, this.den); /*  should eliminate - sign*/

            } else {
                GCD = reduceSimpleFractionToLowestTerms(-this.num, this.den);
            }
            this.num = this.num / GCD; /*then reduce numbers : num/GCD and den/GCD*/

            this.den = this.den / GCD;
        }
    }	// end reduceSimpleFractionToLowestTerms


    private int reduceSimpleFractionToLowestTerms(int num, int den) {/*private int for reducesSimpleFractionToLowestTerms*/

        throw new SimpleFractionException();
    }

    private int GCD(int integerOne, int integerTwo)/* Computes the greatest common divisor of two integers.*/ {
        int result;
        if (integerOne % integerTwo == 0)          /*integerOne is an integer and integerTwo is another integer*/ {
            result = integerTwo;
        } else {
            result = GCD(integerTwo, integerOne % integerTwo);
        }
        return result;/* returns the greatest common divisor of the two integers */

    }	// end GCD

    public static void main(String[] args) {/*main method*/

        {
            SimpleFractionInterface firstOperand = null;
            SimpleFractionInterface secondOperand = null;
            SimpleFractionInterface result = null;
            double doubleResult = 0.0;

            SimpleFraction nineSixteenths = new SimpleFraction(9, 16);  // 9/16
            SimpleFraction oneFourth = new SimpleFraction(1, 4);        // 1/4

            System.out.println("\n=========================================\n");
            // 7/8 + 9/16
            firstOperand = new SimpleFraction(7, 8);
            System.out.println("The sum of " + firstOperand + " and "
                    + nineSixteenths + " is \t\t" + result);
            System.out.println("\tExpected result :\t\t23/16\n");

            // 9/16 - 7/8
            firstOperand = nineSixteenths;
            secondOperand = new SimpleFraction(7, 8);
            System.out.println("The difference of " + firstOperand
                    + " and " + secondOperand + " is \t" + result);
            System.out.println("\tExpected result :\t\t-5/16\n");

            // 15/-2 * 1/4
            firstOperand = new SimpleFraction(15, -2);
            System.out.println("The product of " + firstOperand
                    + " and " + oneFourth + " is \t" + result);
            System.out.println("\tExpected result :\t\t-15/8\n");

            // (-21/2) / (3/7)
            firstOperand = new SimpleFraction(-21, 2);
            secondOperand = new SimpleFraction(3, 7);
            System.out.println("The quotient of " + firstOperand
                    + " and " + secondOperand + " is \t" + result);
            System.out.println("\tExpected result :\t\t-49/2\n");

            // -21/2 + 7/8
            firstOperand = new SimpleFraction(-21, 2);
            secondOperand = new SimpleFraction(7, 8);
            System.out.println("The sum of " + firstOperand
                    + " and " + secondOperand + " is \t\t" + result);
            System.out.println("\tExpected result :\t\t-77/8\n");

            // 0/10, 5/(-15), (-22)/7
            firstOperand = new SimpleFraction(0, 10);
            doubleResult = firstOperand.toDouble();
            System.out.println("The double floating point value of " + firstOperand + " is \t" + doubleResult);
            System.out.println("\tExpected result \t\t\t0.0\n");
            firstOperand = new SimpleFraction(1, -3);
            doubleResult = firstOperand.toDouble();
            System.out.println("The double floating point value of " + firstOperand + " is \t" + doubleResult);
            System.out.println("\tExpected result \t\t\t-0.333333333...\n");
            firstOperand = new SimpleFraction(-22, 7);
            doubleResult = firstOperand.toDouble();
            System.out.println("The double floating point value of " + firstOperand + " is \t" + doubleResult);
            System.out.println("\tExpected result \t\t\t-3.142857142857143");
            System.out.println("\n=========================================\n");
            firstOperand = new SimpleFraction(-21, 2);
            System.out.println("First = " + firstOperand);
            // equality check
            System.out.println("check First equals First: ");
            if (firstOperand.equals(firstOperand)) {
                System.out.println("Identity of fractions OK");
            } else {
                System.out.println("ERROR in identity of fractions");
            }

            secondOperand = new SimpleFraction(-42, 4);
            System.out.println("\nSecond = " + secondOperand);
            System.out.println("check First equals Second: ");
            if (firstOperand.equals(secondOperand)) {
                System.out.println("Equality of fractions OK");
            } else {
                System.out.println("ERROR in equality of fractions");
            }

            // comparison check
            SimpleFraction first = (SimpleFraction) firstOperand;
            SimpleFraction second = (SimpleFraction) secondOperand;

            System.out.println("\ncheck First compareTo Second: ");
            if (first.compareTo(second) == 0) {
                System.out.println("SimpleFractions == operator OK");
            } else {
                System.out.println("ERROR in fractions == operator");
            }

            second = new SimpleFraction(7, 8);
            System.out.println("\nSecond = " + second);
            System.out.println("check First compareTo Second: ");
            if (first.compareTo(second) < 0) {
                System.out.println("SimpleFractions < operator OK");
            } else {
                System.out.println("ERROR in fractions < operator");
            }

            System.out.println("\ncheck Second compareTo First: ");
            if (second.compareTo(first) > 0) {
                System.out.println("SimpleFractions > operator OK");
            } else {
                System.out.println("ERROR in fractions > operator");
            }

            System.out.println("\n=========================================");

            System.out.println("\ncheck SimpleFractionException: 1/0");
            try {
                SimpleFraction a1 = new SimpleFraction(1, 0);
                System.out.println("Error! No SimpleFractionException");
            } catch (SimpleFractionException fe) {
                System.err.printf("Exception: %s\n", fe);
            } // end catch
            System.out.println("Expected result : SimpleFractionException!\n");

            System.out.println("\ncheck SimpleFractionException: division");
            try {
                SimpleFraction a2 = new SimpleFraction();
                SimpleFraction a3 = new SimpleFraction(1, 2);
                a3.divide(a2);
                System.out.println("Error! No SimpleFractionException");
            } catch (SimpleFractionException fe) {
                System.err.printf("Exception: %s\n", fe);
            } // end catch
            System.out.println("Expected result : SimpleFractionException!\n");

        }	// end main
    } // end SimpleFraction

    /*override to implement all abstract methods*/
    @Override
    public int getnumerator() {
        throw new SimpleFractionException();
    }

    @Override
    public int getdenominator() {
        throw new SimpleFractionException();
    }

    @Override
    public int getden() {
        throw new SimpleFractionException();
    }

    @Override
    public int getnum() {
        throw new SimpleFractionException();
    }

    @Override
    public SimpleFractionInterface multiply(SimpleFraction secondFraction) {
        throw new SimpleFractionException();
    }

}
