/*************************************************************************************
 *
 * This class represents a fraction whose numerator and denominator are integers.
 *
 * Requirements:
 *      Implement interfaces: SimpleFractionInterface and Comparable (i.e. compareTo())
 *      Implement methods equals() and toString() from class Object
 *
 *      Should work for both positive and negative fractions
 *      Must always reduce fraction to lowest term 
 *      For a fraction such as 3/-10, it is same as -3/10 (see hints 2. below)
 *      Must display negative fraction as -x/y,
 *         example: (-3)/10 or 3/(-10), must display as -3/10
 *      Must throw SimpleFractionException in case of errors, do not throw other types of exception objects
 *      Must not add new or modify existing data fields
 *      Must not add new public methods
 *      May add private methods
 *
 * Hints:
 *
 * 1. To reduce a fraction such as 4/8 to lowest terms, you need to divide both
 *    the numerator and the denominator by their greatest common denominator.
 *    The greatest common denominator of 4 and 8 is 4, so when you divide
 *    the numerator and denominator of 4/8 by 4, you get the fraction 1/2.
 *    The recursive algorithm which finds the greatest common denominator of
 *    two positive integers is implemnted (see code)
 *       
 * 2. It will be easier to determine the correct sign of a fraction if you force
 *    the fraction's denominator to be positive. However, your implementation must 
 *    handle negative denominators that the client might provide.
 *           
 * 3. You need to downcast reference parameter SimpleFractionInterface to SimpleFraction if  
 *    you want to use it as SimpleFraction. See add, subtract, multiply and divide methods
 *
 * 4. Use "this" to access this object if it is needed
 *
 ************************************************************************************/

package projects.first;

import java.util.Scanner;

public class SimpleFraction implements SimpleFractionInterface, Comparable<SimpleFraction>
{
	private int num;	
	private	int den;	
	public SimpleFraction()
	{
		num = 0;
		den = 1;
	}
	
	public SimpleFraction(int num, int den)
	{
		this.num = num;
		this.den = den;
		if (this.den == 0)
			throw new SimpleFractionException("Denominator is 0");
	}	// end constructor

	public void setSimpleFraction(int num, int den)
	{
		this.num = num;
		this.den = den;
		if (den == 0)
			throw new SimpleFractionException("Denominator is 0");
		
	}	// end setSimpleFraction

	public double toDouble()
	{
		double sum = (this.num) / ((float)this.den);
		return sum;
	}	// end toDouble 

	public SimpleFractionInterface add(SimpleFractionInterface secondFraction)
	{
		SimpleFraction num2 = (SimpleFraction)secondFraction;
		SimpleFraction Sum = reduceSimpleFractionToLowestTerms
		(((this.num * num2.den) + (num2.num * this.den)), ((this.den) * (num2.den))); 
		
		return Sum;
	}	// end add

	public SimpleFractionInterface subtract(SimpleFractionInterface secondFraction)
	{
		SimpleFraction num2 = (SimpleFraction)secondFraction;		
		SimpleFraction Sum = reduceSimpleFractionToLowestTerms
		(((this.num * num2.den) - (num2.num * this.den)), ((this.den) * (num2.den)));
		
		return Sum;
		}	// end subtract

	public SimpleFractionInterface multiply(SimpleFractionInterface secondFraction)
	{
		SimpleFraction num2 = (SimpleFraction)secondFraction;
		SimpleFraction Sum = reduceSimpleFractionToLowestTerms
				(((this.num) * (num2.num)), ((this.num) * (num2.num)));
		
		return Sum;
	}	// end multiply

	public SimpleFractionInterface divide(SimpleFractionInterface secondFraction)
	{
		SimpleFraction num2 = (SimpleFraction)secondFraction;
		int sumN = (this.num) * (num2.den);
		int sumD =  (this.den) * (num2.num);
		sumD = Math.abs(sumD);
		
		if (sumD == 0)
			throw new SimpleFractionException("Second Fraction is 0"); 

		SimpleFraction Sum = reduceSimpleFractionToLowestTerms(sumN, sumD); 
		
		return Sum;		
	}	// end divide

	public SimpleFractionInterface getReciprocal() 
	{				
		SimpleFraction Sum = reduceSimpleFractionToLowestTerms(this.den, this.num);

		return Sum;
	} // end getReciprocal


	public boolean equals(SimpleFraction other)
	{
		double temp1 = (this.num / this.den);
		double temp2 = (other.num / other.den);
		
		if (temp1 == temp2)
			return true;
		else
			return false;
	} // end equals


	public int compareTo(SimpleFraction other)
	{
		if ((this.num / this.den) < (other.num / other.den))
			return -1;
		else if ((this.num / this.den) > (other.num / other.den))
			return 1;
		else
			return 0;
	} // end compareTo

	
	public String toString()
	{
		String s;
		
		if (this.den == 1)
			s = String.valueOf(this.num);
		else
			s = String.valueOf(this.num) + "/" + String.valueOf(this.den);
		return s;
	} // end toString


        //-----------------------------------------------------------------
        //  private methods start here
        //-----------------------------------------------------------------
	/** Task: Reduces a fraction to lowest terms. */
	
	private SimpleFraction reduceSimpleFractionToLowestTerms(int num, int den)
	{		
		int GCD = GCD(num, den);
		int sumN = Math.abs(num / GCD) ;
		int sumD = Math.abs(den / GCD) ;
		
		if (num < 0)
			sumN *= -1;
		else if (den < 0)
			sumN *= -1;
			
		SimpleFraction Sum = new SimpleFraction(sumN, sumD);
			
			return Sum;
	}	// end reduceSimpleFractionToLowestTerms

  	/** Task: Computes the greatest common divisor of two integers.
	 *  @param integerOne	 an integer
	 *  @param integerTwo	 another integer
	 *  @return the greatest common divisor of the two integers */
	private int GCD(int integerOne, int integerTwo)
	{
		 int result;

		 if (integerTwo == 0)
				throw new SimpleFractionException("second Fraction is 0"); 
		 if (integerOne % integerTwo == 0)
			result = integerTwo;
		 else
			result = GCD(integerTwo, integerOne % integerTwo);
		 
		 		 return result;
	}	// end GCD


	//-----------------------------------------------------------------
	//  Simple test is provided here 
	//-----------------------------------------------------------------

public static void main(String[] args) {
		int opr = 0;
	do {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Choos operating sign:- \n0) exit \t1) + \t2) - \t3) * \t4) / \n5) "
				+ "Get Reciprocal \t6) toDouble \n7) CompareTo \t8) equals");
		opr = input.nextInt();
		int f1n, f1d, f2n, f2d;
		SimpleFraction temp2 = null;
		
		if (opr == 0)
			System.exit(0);
		
		System.out.print("Enter 1st fractions Numerator:-\t\t ");
		f1n = input.nextInt();
		System.out.print("\t\t\t\t\t---\nEnter 1st fractions Denominator:-\t ");
		f1d = input.nextInt();
		
		if (opr != 5 && opr != 6) { // check if need 2nd fraction or not.
			System.out.print("Enter 2nd fractions Numerator:-\t\t ");
			f2n = input.nextInt();
			System.out.print("\t\t\t\t\t---\nEnter 2nd fractions Denominator:-\t ");
			f2d = input.nextInt();
			temp2 = new SimpleFraction(f2n, f2d);
			}
		SimpleFraction temp1 = new SimpleFraction(f1n, f1d);
		SimpleFraction answer = null;
		String answerS = null;
		int answerI = 0;
		
		switch (opr){
			//case 0: System.exit(0);
			case 1:	answer = (SimpleFraction)temp1.add(temp2);    
					answerS = answer.toString();
					System.out.println("ANSWER is: " + answerS);
					break;
			case 2: answer = (SimpleFraction)temp1.subtract(temp2);
					answerS = answer.toString();
					System.out.println("ANSWER is: " + answerS);
					break;
			case 3:	answer = (SimpleFraction)temp1.multiply(temp2);
					answerS = answer.toString();
					System.out.println("ANSWER is: " + answerS);
					break;
			case 4:	answer = (SimpleFraction)temp1.divide(temp2);
					answerS = answer.toString();
					System.out.println("ANSWER is: " + answerS);
					break;
			case 5:	answer = (SimpleFraction)temp1.getReciprocal();					
					System.out.println("ANSWER is: " + answer.num + "/" + answer.den);
					break;
			case 6:	answer = temp1;
					answerS = String.valueOf(answer.toDouble());
					System.out.println("ANSWER is: " + answerS);
					break;
			case 7:	answerI = temp1.compareTo(temp2);
					answerS = String.valueOf(answerI);
					System.out.println("ANSWER is: " + answerS);
					break;		
			case 8:	answerS = String.valueOf(temp1.equals(temp2));
					System.out.println("ANSWER is: " + answerS);
					break;	
			default: break;
		}
	}while(true);
	}
}// end SimpleFraction