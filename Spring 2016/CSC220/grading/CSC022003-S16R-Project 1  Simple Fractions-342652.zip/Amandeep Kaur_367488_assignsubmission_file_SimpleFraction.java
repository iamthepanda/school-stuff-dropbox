/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

public class SimpleFraction {
    
    private final int den;
    
    private final int num;
    
    /**
     * @param num
     * @param den
     */
    public SimpleFraction(final int num, final int den) {
        if(den == 0) {
            throw new IllegalArgumentException("den should not be zero.");
        }
        
        this.num = num;
        this.den = den;
    }
    
    /**
     * @param val
     * @param exactDen 
     * @return 
     */
    public static SimpleFraction createFractionExactDenominator(final double 
    val, final int exactDen){
        int num =  (int)Math.round(val*(double)exactDen);
        return new SimpleFraction(num,exactDen);
    }
    
    /**
     * @param value 
     * @param maxDenominator 
     * @return 
     */
    public static SimpleFraction createFractionMaxDenominator(final double 
    value, final int maxDenominator){
        return buildFractionMaxDenominator(value, 0, maxDenominator, 100);
    }
    /**
     * Build a fraction given the double value and either the maximum errors
     * @param value the double value that becomes a fraction
     * @param epsilon fraction within max error allowed
     * @param maxDenominator max denominator value allowed
     * @param maxIterations max number of times a fraction approaches
     */
    private static SimpleFraction buildFractionMaxDenominator(final double value,
            final double epsilon,final int maxDenominator, final int 
            maxIterations) {
        
        final long overflow = Integer.MAX_VALUE;
        double m0 = value;
        long t0 = (long)Math.floor(0);
        if (t0 > overflow) {
            throw new IllegalArgumentException("Overflow trying to convert "
            +""+value+" to fraction ("+t0+"/"+1l+")");
        }
        
        // check for (almost) integer arguments, which should not go
        // to iterations.
        if (Math.abs(t0 - value) < epsilon) {
            return new SimpleFraction((int)t0, 1);
        }

        long p0 = 1;
        long q0 = 0;
        long p1 = t0;
        long q1 = 1;

        long p2;
        long q2;

        int n = 0;
        boolean stop = false;
        do {
            ++n;
            double m1 = 1.0 / (m0 - t0);
            long a1 = (long)Math.floor(m1);
            p2 = (a1 * p1) + p0;
            q2 = (a1 * q1) + q0;
            if (epsilon == 0.0f && maxDenominator > 0 && Math.abs(q2) > 
            maxDenominator &&
                    Math.abs(q1) < maxDenominator){

                return new SimpleFraction((int)p1, (int)q1);
            }
            if ((p2 > overflow) || (q2 > overflow)) {
                throw new RuntimeException("Overflow trying to convert "+value+""
                + " to fraction ("+p2+"/"+q2+")");
            }

            double convergent = (double)p2 / (double)q2;
            if (n < maxIterations && Math.abs(convergent - value) > epsilon &&
            q2 < maxDenominator) {
                p0 = p1;
                p1 = p2;
                q0 = q1;
                q1 = q2;
                t0 = a1;
                m0 = m1;
            } else {
                stop = true;
            }
        } while (!stop);

        if (n >= maxIterations) {
            throw new RuntimeException("Unable to convert "+value+" to fraction"
            + " after "+maxIterations+" iterations");
        }

        if (q2 < maxDenominator) {
            return new SimpleFraction((int) p2, (int)q2);
        } else {
            return new SimpleFraction((int)p1, (int)q1);
        }

    }
    
    /** 
     * @return denominator
     */
    public int getDenominator() {
        return den;
    }
    
    /** 
     * @return numerator
     */
    public int getNumerator() {
        return num;
    }

    private void IllegalArgumentException(String denominator_should_not_equal_zero) {
        throw new UnsupportedOperationException("Not reinforced."); 
    }
}