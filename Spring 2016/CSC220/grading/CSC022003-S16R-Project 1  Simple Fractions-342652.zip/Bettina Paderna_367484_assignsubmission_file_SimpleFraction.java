package PJ1;

public class SimpleFraction implements SimpleFractionInterface, Comparable<SimpleFraction>
{
	// integer numerator and denominator
	private	int num;	
	private	int den;	

	public SimpleFraction()
	{
            num = 0;
            den = 1;
		// implement this method!
		// set fraction to default = 0/1
	}	// end default constructor

	public SimpleFraction(int n, int d)
	{
            num = n;
            den = d;
		// implement this method!
	}	// end constructor

	public void setSimpleFraction(int n, int d)
	{
            if(d==0){
                return SimpleFractionException;
            }
            else{
                num = n;
                den = d;
            }
		// implement this method!
		// return SimpleFractionException if initialDenominator is 0
	}	// end setSimpleFraction

	public double toDouble()
	{
            return((double)(num)/(double)(den));
                // implement this method!
		// return double floating point value
	}	// end toDouble 

	public SimpleFractionInterface add(SimpleFractionInterface secondFraction)
	{
            SimpleFraction taco = new SimpleFraction();
            taco = secondFraction;
            num = (num*taco.den)+(taco.num*den);
            den = (den*taco.den);
            
                // implement this method!
		// a/b + c/d is (ad + cb)/(bd)
                // return result which is a new SimpleFraction object
            SimpleFraction salsa = new SimpleFraction(num,den);
            return salsa;
	}	// end add

	public SimpleFractionInterface subtract(SimpleFractionInterface secondFraction)
	{
            SimpleFraction taco = new SimpleFraction();
            taco = secondFraction;
            num = (num*taco.den)-(taco.num*den);
            den = (den*taco.den);
                // implement this method!
		// a/b - c/d is (ad - cb)/(bd)
                // return result which is a new SimpleFraction object
            SimpleFraction salsa = new SimpleFraction(num,den);
            return salsa;
	}	// end subtract

	public SimpleFractionInterface multiply(SimpleFractionInterface secondFraction)
	{
            SimpleFraction taco = new SimpleFraction();
            taco = secondFraction;
            num = (num*taco.num);
            den = (den*taco.den);
                // implement this method!
		// a/b * c/d is (ac)/(bd)
                // return result which is a new SimpleFraction object
            SimpleFraction salsa = new SimpleFraction(num,den);
            return salsa;
	}	// end multiply

	public SimpleFractionInterface divide(SimpleFractionInterface secondFraction)
	{
            SimpleFraction taco = new SimpleFraction();
            taco = secondFraction;
            num = (num*taco.den);
            den = (den*taco.num);
                // implement this method!
		// a/b / c/d is (ad)/(bc)
		// return SimpleFractionException if secondFraction is 0
                // return result which is a new SimpleFraction object
            if(taco.num == 0){
                return SimpleFractionException;
            }
            SimpleFraction salsa = new SimpleFraction(num,den);
            return salsa;
	}	// end divide

	public SimpleFractionInterface getReciprocal() 
	{
            int taco = num;
            num = den;
            den = taco;
                // implement this method!
		// return SimpleFractionException if secondFraction is 0
                // return result which is a new SimpleFraction object
            if(taco.num==0){
                return SimpleFractionException;
            }
            SimpleFraction salsa = new SimpleFraction(num,den);
            return salsa;
	} // end getReciprocal


	public boolean equals(Object other)
	{
            if(this.compareTo((SimpleFraction)other)==0){
                return true;
        }
                // implement this method!
                return false;
	} // end equals


	public int compareTo(SimpleFraction other)
	{
            if(this.compareTo((SimpleFraction)other)==1){
                return 1;
            }
            else if(this.compareTo((SimpleFraction)other)==-1){
                return -1;
            }
                // implement this method!
                return 0;
	} // end compareTo

	
	public String toString()
	{
		return num + "/" + den;
	} // end toString


	/** Task: Reduces a fraction to lowest terms. */

        //-----------------------------------------------------------------
        //  private methods start here
        //-----------------------------------------------------------------

	private void reduceSimpleFractionToLowestTerms()
	{
            if(num<0){
                num = -num;
            }
            if(den<0){
                den = -den;
            }
            int taquitos = GCD(num,den);
            num = num/taquitos;
            den = den/taquitos;
                // implement this method!
                //
                // Outline:
                // compute GCD of num & den
                // GCD works for + numbers.
                // So, you should eliminate - sign
                // then reduce numbers : num/GCD and den/GCD
		
	}	// end reduceSimpleFractionToLowestTerms

  	/** Task: Computes the greatest common divisor of two integers.
	 *  @param integerOne	 an integer
	 *  @param integerTwo	 another integer
	 *  @return the greatest common divisor of the two integers */
	private int GCD(int integerOne, int integerTwo)
	{
		 int result;

		 if (integerOne % integerTwo == 0)
			result = integerTwo;
		 else
			result = GCD(integerTwo, integerOne % integerTwo);

		 return result;
	}	// end GCD


	//-----------------------------------------------------------------
	//  Simple test is provided here 

	public static void main(String[] args)
	{
		SimpleFractionInterface firstOperand = null;
		SimpleFractionInterface secondOperand = null;
		SimpleFractionInterface result = null;
                double doubleResult = 0.0;

		SimpleFraction nineSixteenths = new SimpleFraction(9, 16);  // 9/16
		SimpleFraction oneFourth = new SimpleFraction(1, 4);        // 1/4

		System.out.println("\n=========================================\n");
		// 7/8 + 9/16
		firstOperand = new SimpleFraction(7, 8);
		result = firstOperand.add(nineSixteenths);
		System.out.println("The sum of " + firstOperand + " and " +
				nineSixteenths + " is \t\t" + result);
		System.out.println("\tExpected result :\t\t23/16\n");

		// 9/16 - 7/8
		firstOperand = nineSixteenths;
		secondOperand = new SimpleFraction(7, 8);
		result = firstOperand.subtract(secondOperand);
		System.out.println("The difference of " + firstOperand	+
				" and " +	secondOperand + " is \t" + result);
		System.out.println("\tExpected result :\t\t-5/16\n");


		// 15/-2 * 1/4
		firstOperand = new SimpleFraction(15, -2); 
		result = firstOperand.multiply(oneFourth);
		System.out.println("The product of " + firstOperand	+
				" and " +	oneFourth + " is \t" + result);
		System.out.println("\tExpected result :\t\t-15/8\n");

		// (-21/2) / (3/7)
		firstOperand = new SimpleFraction(-21, 2); 
		secondOperand= new SimpleFraction(3, 7); 
		result = firstOperand.divide(secondOperand);
		System.out.println("The quotient of " + firstOperand	+
				" and " +	secondOperand + " is \t" + result);
		System.out.println("\tExpected result :\t\t-49/2\n");

		// -21/2 + 7/8
		firstOperand = new SimpleFraction(-21, 2); 
		secondOperand= new SimpleFraction(7, 8); 
		result = firstOperand.add(secondOperand);
		System.out.println("The sum of " + firstOperand	+
				" and " +	secondOperand + " is \t\t" + result);
		System.out.println("\tExpected result :\t\t-77/8\n");


                // 0/10, 5/(-15), (-22)/7
		firstOperand = new SimpleFraction(0, 10); 
                doubleResult = firstOperand.toDouble();
		System.out.println("The double floating point value of " + firstOperand	+ " is \t" + doubleResult);
		System.out.println("\tExpected result \t\t\t0.0\n");
		firstOperand = new SimpleFraction(1, -3); 
                doubleResult = firstOperand.toDouble();
		System.out.println("The double floating point value of " + firstOperand	+ " is \t" + doubleResult);
		System.out.println("\tExpected result \t\t\t-0.333333333...\n");
		firstOperand = new SimpleFraction(-22, 7); 
                doubleResult = firstOperand.toDouble();
		System.out.println("The double floating point value of " + firstOperand	+ " is \t" + doubleResult);
		System.out.println("\tExpected result \t\t\t-3.142857142857143");
		System.out.println("\n=========================================\n");
		firstOperand = new SimpleFraction(-21, 2); 
		System.out.println("First = " + firstOperand);
		// equality check
		System.out.println("check First equals First: ");
		if (firstOperand.equals(firstOperand))
			System.out.println("Identity of fractions OK");
		else
			System.out.println("ERROR in identity of fractions");

		secondOperand = new SimpleFraction(-42, 4); 
		System.out.println("\nSecond = " + secondOperand);
		System.out.println("check First equals Second: ");
		if (firstOperand.equals(secondOperand))
			System.out.println("Equality of fractions OK");
		else
			System.out.println("ERROR in equality of fractions");

		// comparison check
		SimpleFraction first  = (SimpleFraction)firstOperand;
		SimpleFraction second = (SimpleFraction)secondOperand;
		
		System.out.println("\ncheck First compareTo Second: ");
		if (first.compareTo(second) == 0)
			System.out.println("SimpleFractions == operator OK");
		else
			System.out.println("ERROR in fractions == operator");

		second = new SimpleFraction(7, 8);
		System.out.println("\nSecond = " + second);
		System.out.println("check First compareTo Second: ");
		if (first.compareTo(second) < 0)
			System.out.println("SimpleFractions < operator OK");
		else
			System.out.println("ERROR in fractions < operator");

		System.out.println("\ncheck Second compareTo First: ");
		if (second.compareTo(first) > 0)
			System.out.println("SimpleFractions > operator OK");
		else
			System.out.println("ERROR in fractions > operator");

		System.out.println("\n=========================================");

		System.out.println("\ncheck SimpleFractionException: 1/0");
		try {
			SimpleFraction a1 = new SimpleFraction(1, 0);		    
		        System.out.println("Error! No SimpleFractionException");
		}
		catch ( SimpleFractionException fe )
           	{
              		System.err.printf( "Exception: %s\n", fe );
           	} // end catch
		System.out.println("Expected result : SimpleFractionException!\n");

		System.out.println("\ncheck SimpleFractionException: division");
		try {
			SimpleFraction a2 = new SimpleFraction();		    
			SimpleFraction a3 = new SimpleFraction(1, 2);		    
			a3.divide(a2);
		        System.out.println("Error! No SimpleFractionException");
		}
		catch ( SimpleFractionException fe )
           	{
              		System.err.printf( "Exception: %s\n", fe );
           	} // end catch
		System.out.println("Expected result : SimpleFractionException!\n");



	}	// end main
} // end SimpleFraction

